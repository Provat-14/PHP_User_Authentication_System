
<!-- =================Script written by DProvat.===================== -->
<!-- Please contact us if there are any errors or problems with usage. https://arprovat.com/  -->

<?php
$servername = "localhost";
$username = "arprovat_Developer";
$password = "password";
$dbname = "database_Name";
$con = new mysqli($servername, $username, $password, $dbname);

if(!$con){
	echo "Database connection fail->";
}else{
    // echo "seccess";
}

?>