
<!-- =================Script written by DProvat.===================== -->
<!-- Please contact us if there are any errors or problems with usage. https://arprovat.com/  -->
<?php


session_start();
require "db.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if(isset($_POST['email'])){
        $email = $_POST['email'];
        $sql = "SELECT * FROM `users_login` WHERE `email` = '$email' ";
        $result = mysqli_query($con, $sql); 
        
        
        if ((mysqli_num_rows($result) > 0)) {
            
            $userData = mysqli_fetch_assoc($result);
            $Id = $userData["id"];
            $userid = $userData["userid"];
            $name = $userData["name"];
            $email = $userData["email"];
            
            $root_domain = 'https://yoursiteurl.com';
        
            $token = bin2hex(random_bytes(32));
        
            $_SESSION['reset_token'] = $token;
            
            $reset_token = $_SESSION['reset_token'];
        
            $reset_link = $root_domain."recoverpswd.html?token=" . $token; 
            
            $adminsEmail= 'admin@yoursiteurl.com';
            $to = $email;
            $subject = $name.' || Reset Password || Your Title ';
            
            $headers = "From: ".$adminsEmail."\r\n";
            $headers .= "Reply-To: ".$adminsEmail."\r\n";
            $headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
            
            $body = "
            <html>
                <head>
                    <title>Your Email Title</title>
                </head>
                <body>            
                    <table style='border: none;'>
                        <tr>
                            <td>Name:</td>
                            <td>".$name."</td>
                        </tr>
                        <tr>
                            <td>userId:</td>
                            <td>".$userid."</td>
                        </tr>
                        <tr>
                            <td>Email:</td>
                            <td>".$email."</td>
                        </tr>
                        <tr>
                            <a href='$reset_link'>reset Link</a>
                        </tr>
                    </table>
                    <a href='$root_domain/login.html'>login here</a>
                </body>
            </html>
            ";
            
          if (mail($to, $subject, $body, $headers)) {
                $sql_update = "UPDATE `users_login` SET `reset_token` = '$reset_token' WHERE `id` = '$Id'";
                $result = mysqli_query($con, $sql_update);
                
                if ($result) {
                    $error = [
                        'error_code' => 0, 
                        'error_text' => 'Recovery mail sent successfully',
                        'error_result' => $result,
                        'error_name' => $name
                    ];
                    exit(json_encode($error));
                } else {
                    $error = [
                        'error_code' => 1, 
                        'error_text' => 'Error updating database: ' . mysqli_error($con)
                    ];
                    exit(json_encode($error));
                }
            } else {
                $error = [
                    'error_code' => 2, 
                    'error_text' => 'Failed to send recovery mail'
                ];
                exit(json_encode($error));
            }
        }else{
            $error = [
                'error_code' => 1, 
                'error_text' => 'User with this email does not exist',
                'error_email' => $email
            ];
            exit(json_encode($error));
        }
    }else{
        if(isset($_POST['token'])){
            $token = $_POST['token']; 
        
            $sql = "SELECT * FROM `users_login` WHERE `reset_token`='$token'";
            $result = mysqli_query($con, $sql); 
            
            
            if ((mysqli_num_rows($result) > 0)) {
                
                $userData = mysqli_fetch_assoc($result);
                $response = [
                    "id" => $userData["id"],
                    "userid" => $userData["userid"],
                    "name" => $userData["name"],
                    "email" => $userData["email"],
                    "token" => $token
                ];
                exit(json_encode($response));
            }else{
                $error = [
                    'error_code' => 22, 
                    'error_text' => 'Invalid token or timeOut'
                ];
                exit(json_encode($error));
            }
        }
        
        if(isset($_POST['updatepswd'])){
            $id = $_POST['id'];
            $password = $_POST['password'];
            $confirm_password = $_POST['confirm_password']; 
            
            if (empty($password)) {
                $error=[
                    'error_code' => 1, 
                    'error_text' => 'Password is required!'
                ];
                
                exit(json_encode($error));
            }
            
            if (empty($confirm_password)) {
                $error=[
                    'error_code' => 1, 
                    'error_text' => 'Confirm Password is required!'
                ];
                
                exit(json_encode($error));
            }
            
        
            if ($password !== $confirm_password) {        
                $error=[
                    'error_code' => 1, 
                    'error_text' => 'Passwords do not match'
                ];
                exit(json_encode($error));
            }else{
                // if($_SESSION['reset_token'] == $token){
                    
                
                    $sql = "UPDATE `users_login` SET `password` = '$password', `reset_token` = '' WHERE `users_login`.`id` = $id;";
                    $result = mysqli_query($con, $sql); 
                    if ($result) {
                        $error = [
                            'error_code' => 0, 
                            'error_text' => 'your Password update successfully',
                            'error_result' => $result
                        ];
                        unset($_SESSION['reset_token']);
                        exit(json_encode($error));
                    }else{
                        $error = [
                            'error_code' => 2, 
                            'error_text' => 'Failed to Password update'
                        ];
                        exit(json_encode($error));
                    }
                // }
            }
        }
    }
}
?>